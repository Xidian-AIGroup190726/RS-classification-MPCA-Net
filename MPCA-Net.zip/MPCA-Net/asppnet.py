import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import get_data
import torch.utils.data
from torch.utils.data import DataLoader
from libtiff import TIFF
import scipy.io as scio
import numpy as np
import cv2
from sklearn.metrics import confusion_matrix

'''
数据:总像素数:664000
有标签数据:313245
训练数据:93971
验证数据:219274
'''
data_path_lab = './label.mat'
data_path_ms = './ms4.tif'
data_path_pan = './pan.tif'
#读取数据和标签
labels = scio.loadmat(data_path_lab)
ms = TIFF.open(data_path_ms, mode='r')
pan = TIFF.open(data_path_pan, mode='r')
image_ms = ms.read_image()
image_pan = pan.read_image()
image_ms = np.array(image_ms).transpose((2,0,1))#调整通道

#data preprosessing
MS_CUT_SIZE = 16
PAN_CUT_SIZE = 64
TRAIN_RATE = 0.3
EPOCH = 30
BATCH_SIZE = 64
LR = 0.0001


m_ms = get_data.mirror(image_ms,MS_CUT_SIZE)#多返回值函数在只返回一个返回元素时是元组
m_pan = get_data.mirror(image_pan,PAN_CUT_SIZE)
print("data")
label = labels['label']#获取标签
label = np.array(label)#转换成numpy数组
total_label = np.max(label)#最大类别数
print(total_label)

#制作训练数据和测试数据位置和标签

for i in range(1, total_label+1):
    index_I = np.where(label==i) #第i类坐标
    index_I = np.array(index_I).T
    len_I = len(index_I)  # 索引总长度
    len_train = int(len_I * TRAIN_RATE)  # 第i类训练样本数
    len_valid = int(len_I-len_train)     # 第i类测试样本数
    index_train = np.arange(len_I) #建立第i类所有索引
    np.random.shuffle(index_train)  # 打乱索引顺序
    label_train_i = i * np.ones((len_train, 1), dtype='int64')  # 第i类训练样本label
    label_valid_i = i * np.ones((len_valid, 1), dtype='int64') # 第i类测试样本label
    if i == 1:
        train_data_label = label_train_i
        train_data_loca = index_I[index_train[:len_train]]
        valid_data_label = label_valid_i
        valid_data_loca = index_I[index_train[len_train:]]
    else:
        train_data_label=np.append(train_data_label, label_train_i, axis=0)
        train_data_loca=np.append(train_data_loca, index_I[index_train[:len_train]], axis=0)#第i类训练样本坐标
        valid_data_label=np.append(valid_data_label, label_valid_i, axis=0)
        valid_data_loca=np.append(valid_data_loca, index_I[index_train[len_train:]], axis=0)
    # label_l[counter:len_I+counter] = i

# print(train_data_label.dtype, train_data_loca.dtype)
train_data_label = train_data_label - 1#label要从0开始
valid_data_label = valid_data_label - 1
train_data_loca = np.hstack((train_data_loca, train_data_label))
valid_data_loca = np.hstack((valid_data_loca, valid_data_label))
all_label_data = np.vstack((train_data_loca, valid_data_loca))
# print(train_data_loca.shape, valid_data_loca.shape)
np.random.shuffle(train_data_loca)
np.random.shuffle(valid_data_loca)
np.random.shuffle(all_label_data)
#数据归一化
m_ms = get_data.to_tensor(m_ms)
m_pan = get_data.to_tensor(m_pan)
m_pan = np.expand_dims(m_pan, axis=0)# 二维数据进网络前要加一维
# print(m_ms.dtype, m_pan.dtype)
train_data = get_data.MyDataset(m_ms, m_pan, train_data_loca, cut_size=MS_CUT_SIZE)
# print(train_data[0][0])
# print(train_data[0][1])
# print(train_data[0][2])
train_loder = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=False, num_workers=2)
valid_data = get_data.MyDataset(m_ms, m_pan, valid_data_loca, cut_size=MS_CUT_SIZE)
valid_loader = DataLoader(valid_data, batch_size=BATCH_SIZE, shuffle=False, num_workers=2)

test_data = get_data.MyDataset(m_ms, m_pan, all_label_data, cut_size=MS_CUT_SIZE)
test_loader = DataLoader(test_data, batch_size=BATCH_SIZE, shuffle=False, num_workers=2)
print(all_label_data.shape)
true_label = all_label_data[:, 2]
pred_label = np.zeros(len(true_label), dtype=int)
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1_1 = nn.Conv2d(
                in_channels=4,
                out_channels=32,
                kernel_size=5,
                stride=1,
                padding=2
            )#output shape(32,16,16)

        self.conv1_2 = nn.Conv2d(1, 32, 5, 1, 2)#output shape(64,64,64) ((input-kernel_size+2*padding)/stride)+1
        self.conv2_1 = nn.Conv2d(32, 64, 5, 1, 2)#output shape(128,16,16)
        self.conv2_2 = nn.Conv2d(32, 64, 5, 1, 2)  # output shape(128,32,32)
        self.conv3 = nn.Conv2d(64, 128, 3, 1, 1)#(128,8,8)
        self.conv4 = nn.Conv2d(128, 256, 3, 1, 1)#(256,4,4)

        #全连接层
        self.fc = nn.Sequential(
            nn.Linear(512*4*4, 256),
            nn.Linear(256, 128),
            nn.Linear(128, 7))


    def forward(self, x1,x2):
        #print(x1.shape, x2.shape)
        x1 = self.conv1_1(x1)#(32,16,16)
        x2 = self.conv1_2(x2)#(32,64,64)
        x1 = F.relu(x1)
        x2 = F.max_pool2d(F.relu(x2), (2, 2))#(32,32,32)
        #print(x1.shape, x2.shape)
        x1 = self.conv2_1(x1)#
        x2 = self.conv2_2(x2)#
        x1 = F.relu(x1)#(64, 16, 16)
        x2 = F.max_pool2d(F.relu(x2), (2, 2))#(64,16,16)
        #print(x1.shape, x2.shape)
        x1 = self.conv3(x1)
        x2 = self.conv3(x2)
        x1 = F.max_pool2d(F.relu(x1), (2, 2))#(128, 8, 8)
        x2 = F.max_pool2d(F.relu(x2), (2, 2))#(128,8,8)
        x1 = self.conv4(x1)
        x2 = self.conv4(x2)
        x1 = F.max_pool2d(F.relu(x1), (2, 2))#(128, 4, 4)
        x2 = F.max_pool2d(F.relu(x2), (2, 2))#(128,4,4)
        x = torch.cat((x1, x2), 1)
        #print(x.shape)
        x = x.view(x.size(0), 512*4*4)
        #print(x.shape)
        output = self.fc(x)

        return output

double_cnn = Net()#net的名称很重要
optimizer = optim.Adam(double_cnn.parameters(), lr=LR, weight_decay=0.00005)
loss_fuc = nn.CrossEntropyLoss()
double_cnn.cuda()#记得用cuda()


for epoch in range(EPOCH):
    valid_batch = iter(valid_loader)  # 验证集迭代器
    for step, (x1, x2, y,r1,r2) in enumerate(train_loder):
        batch_x1 = torch.tensor(x1, dtype=torch.float32).cuda()#dtype记得改一致
        batch_x2 = torch.tensor(x2, dtype=torch.float32).cuda()
        y = y.cuda()
        output = double_cnn(batch_x1, batch_x2)
        loss = loss_fuc(output, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if step%100 == 0:
            ls = loss.data.cpu().numpy()
            #print(ls)
            x1, x2, y ,t1,t2= next(valid_batch)
            y1 = y.data.numpy()
            # print(y1.dtype)
            # print(y1)
            batch_v1 = torch.tensor(x1, dtype=torch.float32).cuda()
            batch_v2 = torch.tensor(x2, dtype=torch.float32).cuda()
            batch_vy = torch.tensor(y)
            valid_output = double_cnn(batch_v1, batch_v2)
            valid_outputs = valid_output.data.cpu().numpy()
            #print(valid_outputs)
            valid_result = np.argmax(valid_outputs,axis=1)
            # print(valid_result.dtype)
            # print(valid_result)
            v_accuracy = 0
            for i,x in enumerate(valid_result):
                 temp = np.where(y1[i]==x, 1, 0)
                 v_accuracy = v_accuracy + temp

            v_accuracy = (v_accuracy/len(valid_result))
            print('Epoch: ', epoch,
                  '|| batch: ', step,
                  '|| train loss: %.4f' % loss.data.cpu().numpy(),
                  '|| valid accuracy: %.2f' % v_accuracy)



out_color = np.zeros((800, 830, 3))
out_result_metricx = np.zeros((800, 830))
loc = 0
for j, (ms, pan, label,z1,z2) in enumerate(test_loader):
    batch_t1 = torch.tensor(ms, dtype=torch.float32).cuda()
    batch_t2 = torch.tensor(pan, dtype=torch.float32).cuda()
    test_label = torch.tensor(label).cuda()
    test_output = double_cnn(batch_t1, batch_t2)
    test_out_data = test_output.data.cpu().numpy()
    test_result = np.argmax(test_out_data, axis=1)
    b, h, w, c = batch_t1.shape
    '''
    cv2三色通道是BGR,matlab是RGB
    '''
    for k, cls in enumerate(test_result):
        x1, y1, lab1 = all_label_data[k + b * j]
        pred_label[loc] = cls
        loc = loc + 1
        if cls == 0:
            out_color[x1][y1] = [203, 192, 255]
            out_result_metricx[x1][y1] = 0
        elif cls == 1:
            out_color[x1][y1] = [14, 132, 241]
            out_result_metricx[x1][y1] = 1
        elif cls == 2:
            out_color[x1][y1] = [255, 255, 0]
            out_result_metricx[x1][y1] = 2
        elif cls == 3:
            out_color[x1][y1] = [0, 0, 255]
            out_result_metricx[x1][y1] = 3
        elif cls == 4:
            out_color[x1][y1] = [51, 102, 153]
            out_result_metricx[x1][y1] = 4
        elif cls == 5:
            out_color[x1][y1] = [0, 255, 0]
            out_result_metricx[x1][y1] = 5
        elif cls == 6:
            out_color[x1][y1] = [255, 0, 0]
            out_result_metricx[x1][y1] = 6

#cv2.imwrite('./output_fusion_'+str(EPOCH)+'_'+str(TRAIN_RATE)+'.png', out_color)
cm = confusion_matrix(true_label, pred_label,labels=[0, 1, 2, 3, 4, 5, 6])
print(['0', '1', '2', '3', '4', '5', '6'])
print(cm)

dsa=0
pe = 0
ses = np.sum(cm,axis=1)
sep = np.sum(cm,axis=0)
print(ses,sep)
for i, cla in enumerate(cm):
    pred = cla[i]
    dsa+=cla[i]
    pe+=sep[i]*ses[i]
    acr = pred / sep[i]
    rep = pred / ses[i]
    f1 = 2*acr*rep / (acr + rep)
    print("第 %d 类: || 准确率: %.7f || 召回率: %.7f || F1: %.7f" % (i, acr, rep, f1))
total_e=np.sum(cm)
p=dsa/total_e
pe=pe/(total_e*total_e)
kappa = (p-pe)/(1-pe)
print("总体准确率: %.7f || kappa: %.7f" % (p, kappa))

