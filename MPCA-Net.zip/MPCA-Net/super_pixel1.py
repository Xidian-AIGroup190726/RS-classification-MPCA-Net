# coding=utf-8
# 导入相应的python包
import argparse
from skimage import io
import matplotlib.pyplot as plt
from skimage.segmentation import quickshift
from skimage.segmentation import slic
from skimage.util import img_as_float
from skimage.segmentation import mark_boundaries
import numpy as np
from skimage.segmentation import find_boundaries

image_width=800
image_height=830
half_cut_size=8

# 设置并解析参数
ap = argparse.ArgumentParser()
ap.add_argument("-i", "--image", required = True, help = "Path to the image")
args = vars(ap.parse_args())

# 读取图片并将其转化为浮点型
image = img_as_float(io.imread(args["image"]))

# 循环设置不同的超像素组
#for numSegments in (400):
	# 应用slic算法并获取分割结果
segments = slic(image, n_segments = 400, sigma = 5)

#创建数组
#保存超像素每个块所含坐标
array=np.zeros((370,5000,2))
print(array.shape)
#保存每个超像素块所含像素数
array1=np.zeros(370)
print(array1.shape)
#保存与中心像素属于同一超像素块的像素数
array3=np.zeros((image_width,image_height))
#保存中心像素的属于的超像素块
center=np.array(segments)
print(center.shape)
#暂时保存以16*16的窗口的分类情况
window=np.array((16,16))

#print("segments:\n",segments)
#print("np.unique(segemnts):",np.unique(segments))
segments_block=np.array(np.unique(segments))
#print(segments_block.size)
segments_block_num=segments_block.size
for i in range(segments_block_num):
    a=np.array(np.where(segments==i))
    a_size=a.shape[1]
    #print(a.shape)
    array1[i]=a_size
    for j in range(a_size):
        array[i][j][0] = a[0][j]
        array[i][j][1] = a[1][j]

for width in range(half_cut_size-1,image_width-half_cut_size):
    for height in range(half_cut_size-1,image_height-half_cut_size):
        window=center[width-half_cut_size+1:width+half_cut_size+1,height-half_cut_size+1:height+half_cut_size+1]
        #print(window)
        #print(center[width][height])
        array3[width][height]=np.sum(window==center[width][height])
        #print(array3[width][height])
    print(width,height,"完毕")
print(array3)
dialation=(np.sqrt(array3)+1)/2
#np.savetxt("sult1.txt", array3,fmt='%d',delimiter=',')
np.savetxt("dialation.txt", dialation,fmt='%d',delimiter=',')


# 绘制结果
#     print('SLIC number of segments: {}'.format(len(np.unique(segments))))
#     fig = plt.figure("Superpixels -- %d segments" % (numSegments))
#     ax = fig.add_subplot(1, 1, 1)
#     ax.imshow(mark_boundaries(image, segments))
#     #ax.imshow(find_boundaries(segments, connectivity=1, mode='thick', background=0))
#     plt.axis("off")
#
# # 显示结果
# plt.show()
